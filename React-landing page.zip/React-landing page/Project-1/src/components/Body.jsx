const Body = () => {
  return (
    <>
      <main className="body similar-properties">
        <div className="left-side">
          <div className="content">
            <h1>YOUR FEET DESERVE THE BEST</h1>
            <p>
              YOUR FEET DESERVE THE BEST AND WE ARE HERE TO HELP YOU WITH OUR
              SHOES.YOUR FEET DESERVE THE BEST AND WE ARE HERE TO HELP YOU WITH
              OUR SHOES.
            </p>
          </div>
          <div className="body-buttons">
            <button className="shop">Shop Now</button>
            <button className="Category">Category</button>
          </div>
          <div className="available">
            <p>Available On:</p>
            <div className="brand-icons">
              <img src="../public/images/amazon.png" alt="" />
              <img src="../public/images/flipkart.png" alt="" />
            </div>
          </div>
        </div>
        <div className="right-side">
          <img src="../public/images/shoe_image.png" alt="" />
        </div>
      </main>
    </>
  );
};

export default Body;
